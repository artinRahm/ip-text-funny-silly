<html lang="en"><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
<link rel="icon" href="/storage/images/googleclassroom.png" type="image/png">   
<link rel="stylesheet" href="/storage/css/404.css">
</head>
<body>

<script src="/particles.js"></script>
<script src="/storage/js/app.js"></script>


    <div class="background"><div id="particles-js"></div></div>
    <div class="container">
        <h1>404</h1>
        <ul>
            <li>this page does not exist or has moved</li>
            <li>check the url and try again</li>
            <li>lost? click home button i dare u</li>
            <li>if you have any issues you can dm me 😏</li>
        </ul>
        <a href="/" class="button">"home button"</a>
    </div>
    <script type="text/javascript" src="/storage/js/settings.js"></script>
    <script type="text/javascript" src="/storage/js/background.js"></script>

</body></html>
